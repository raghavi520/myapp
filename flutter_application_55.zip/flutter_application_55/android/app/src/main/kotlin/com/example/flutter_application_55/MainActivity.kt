package com.example.flutter_application_55

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
